# Changelog

All notable changes to this project will be documented in this file.

The format is inspired by Keep a Changelog and follows Semantic Versioning.

## [0.7.0] - 2026-07

### Added

- Introduced multi-module architecture.
- Added agentflow-core module.
- Added spring boot starter module.
- Added AutoConfiguration support.
- Added AgentFlowProperties.
- Added ChatClientAutoConfiguration.
- Added conditional configuration support.

### Changed

- Demo application now consumes AgentFlow through starter dependency.
- Framework beans are provided by starter instead of demo configuration.

## [0.5.0] - 2026-07

### Added

- Added @Agent annotation.
- Added AgentFactory.
- Added AgentScanner.
- Added AgentRegistry.
- Added AgentResolver.
- Added agent-name based execution support.

### Changed

- Improved Agent execution API with `execute(String agentName, AgentRequest request)`.

## [0.4.0] - 2026-07

### Added

- Added PromptTemplate.
- Added PromptLoader for loading prompt files from resources.
- Added PromptManager for prompt registration and lookup.
- Added PromptRenderer for prompt variable rendering.
- Added PromptVariables.
- Added PromptContext.
- Added Agent model.
- Added AgentRequest and AgentResponse.
- Added AgentExecutor as the first Agent execution pipeline.

### Changed

- Refactored execution flow from chat-based execution to agent-based execution.

## [0.3.0] - 2026-07

### Added

- Introduced annotation-driven Tool Framework.
- Added ToolMetadata and ToolDefinition.
- Added ToolScanner for automatic tool discovery.
- Added ToolRegistry for centralized tool management.
- Introduced @AgentTool annotation.

## [0.2.0] - 2026-07

### Added

- Introduced AIContext for unified AI execution context.
- Added PromptManager for centralized prompt management.
- Added ToolRegistry for tool registration.
- Added ChatExecutor to separate AI execution from business services.
- Added Order domain (OrderInfo, OrderService, OrderRepository, OrderTool).

### Changed

- Refactored ChatService to delegate AI requests to ChatExecutor.
- Improved project architecture by separating AI infrastructure from business modules.

## [0.1.0] - 2026-06

### Added

- Initial Spring Boot project.
- Integrated Spring AI.
- Implemented ChatClient.
- Added ChatController and ChatService.
- Added TimeTool, WeatherTool and CalculatorTool.